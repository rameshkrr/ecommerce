 <ul class="col-sm-4  adminmenu">
          <li> <a href="index.php?insert_product">Insert New Products</a></li>

          <li> <a href="index.php?view_products">View All Products</a></li>

          <li> <a href="index.php?insert_cat">Insert New Category</a></li>

          <li> <a href="index.php?view_cat">View All Category</a></li>

          <li> <a href="index.php?insert_brands">Insert New Brand</a></li>

          <li> <a href="index.php?view_brands">View All Brands</a></li>

          <li> <a href="index.php?view_customers">View Customers</a></li>

          <li> <a href="index.php?view_orders">View Orders</a></li>

          <li> <a href="index.php?view_payments">View Payment</a></li>

          <li> <a href="logoutadmin.php">Logout</a></li>
        </ul>