<?php
 $con = mysqli_connect("localhost","root","dellinspiron5521","ecommerce");